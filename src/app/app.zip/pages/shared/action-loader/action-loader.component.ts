import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-action-loader',
  templateUrl: './action-loader.component.html',
  styleUrls: ['./action-loader.component.scss']
})
export class ActionLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
